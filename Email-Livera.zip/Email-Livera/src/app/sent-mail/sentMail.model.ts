export class Email {
  constructor(public email : string, public object: string, public message?: string) {} 
}